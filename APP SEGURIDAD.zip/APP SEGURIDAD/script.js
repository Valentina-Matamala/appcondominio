// Función para cambiar entre pantallas
function irA(pantalla) {
    const pantallas = document.querySelectorAll('.screen');
    pantallas.forEach(p => p.classList.remove('active'));
    document.getElementById(pantalla).classList.add('active');
}

// Actualizar fecha y hora
function actualizarFechaHora() {
    const fechaHora = new Date().toLocaleString('es-CL', {
        timeZone: 'America/Santiago'
    });
    document.getElementById('fecha-hora').textContent = `Fecha y Hora: ${fechaHora}`;
}

setInterval(actualizarFechaHora, 1000);

// Simula el inicio de sesión
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita que el formulario se envíe
    const email = document.getElementById('email').value;
    const pin = document.getElementById('pin').value;

    if (email && pin) {
        irA('menu-principal');  // Simula que el usuario ha ingresado correctamente
    } else {
        alert('Por favor, ingresa el correo electrónico y el código PIN.');
    }
});
